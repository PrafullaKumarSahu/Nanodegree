package com.android.serverwarrior.myappportfolio;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button media_streamer;
    Button super_duo1;
    Button super_duo2;
    Button ant_terminator;
    Button materialize;
    Button capstone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        media_streamer = (Button) findViewById(R.id.media_streamer);
        super_duo1 = (Button) findViewById(R.id.super_duo1);
        super_duo2 = (Button) findViewById(R.id.super_duo2);
        ant_terminator = (Button) findViewById(R.id.ant_terminator);
        materialize = (Button) findViewById(R.id.materialize);
        capstone = (Button) findViewById(R.id.capstone);

        media_streamer.setOnClickListener(new HandleClick());
        super_duo1.setOnClickListener(new HandleClick());
        super_duo2.setOnClickListener(new HandleClick());
        ant_terminator.setOnClickListener(new HandleClick());
        materialize.setOnClickListener(new HandleClick());
        capstone.setOnClickListener(new HandleClick());

        media_streamer.setOnTouchListener(new HandleTouch());
        super_duo1.setOnTouchListener(new HandleTouch());
        super_duo2.setOnTouchListener(new HandleTouch());
        ant_terminator.setOnTouchListener(new HandleTouch());
        materialize.setOnTouchListener(new HandleTouch());
        capstone.setOnTouchListener(new HandleTouch());
    }


     private class HandleClick implements View.OnClickListener{
                @Override
                public void onClick(View v) {
                    Button btn = (Button) v;
                    String text = btn.getText().toString();
                    Toast toast = Toast.makeText(getApplicationContext(),"This button will laucnch my " + text + " app !", Toast.LENGTH_SHORT);
                    toast.show();
                }
     }

    private class HandleTouch implements  View.OnTouchListener{
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            Button btn = (Button) v;
            if(event.getAction() == MotionEvent.ACTION_DOWN) {
                btn.setBackgroundResource(R.color.btnClick);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                btn.setBackgroundResource(R.color.btBackground);
            }
            return false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
